-- Skema database: Profil Kelas XI TKJ 3 — SMK Telkom Malang
-- LAB KEAMANAN WEB — skema ini sengaja dipakai bersama backend yang rentan.
-- Jalankan sekali di server MariaDB lab kamu:
--   mysql -u root -p < database/schema.sql

CREATE DATABASE IF NOT EXISTS xi_tkj_3
  CHARACTER SET utf8mb4
  COLLATE utf8mb4_unicode_ci;

USE xi_tkj_3;

DROP TABLE IF EXISTS students;

CREATE TABLE students (
  id              INT AUTO_INCREMENT PRIMARY KEY,
  foto            VARCHAR(255)  NOT NULL DEFAULT 'placeholder.svg',
  nama_lengkap    VARCHAR(150)  NOT NULL,
  nama_panggilan  VARCHAR(50)   NOT NULL,
  kelas           VARCHAR(30)   NOT NULL DEFAULT 'XI TKJ 3',
  keahlian        VARCHAR(150)  NOT NULL,
  skill           VARCHAR(255)  NOT NULL,
  hobi            VARCHAR(255)  NOT NULL,
  cita_cita       VARCHAR(150)  NOT NULL,
  -- deskripsi disimpan & dirender APA ADANYA (raw) secara sengaja untuk
  -- mendemonstrasikan celah Stored XSS. Lihat src/app/students/[id]/page.tsx
  deskripsi       TEXT          NULL,
  created_at      TIMESTAMP     NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at      TIMESTAMP     NOT NULL DEFAULT CURRENT_TIMESTAMP
                                 ON UPDATE CURRENT_TIMESTAMP
);

-- Index biasa untuk nama (TIDAK melindungi dari SQL Injection karena
-- endpoint pencarian memakai string concatenation mentah, bukan
-- prepared statement — itu memang tujuan labnya).
CREATE INDEX idx_students_nama ON students (nama_lengkap);
