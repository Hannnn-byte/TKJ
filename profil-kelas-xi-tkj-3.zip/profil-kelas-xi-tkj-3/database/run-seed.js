/**
 * Alternatif untuk `mysql -u root -p < database/schema.sql` dan
 * `... < database/seed.sql` bagi yang tidak punya CLI mysql terpasang.
 *
 * Pakai:  npm run seed
 * Membaca kredensial dari .env.local (format KEY=VALUE sederhana).
 */
const fs = require("fs");
const path = require("path");
const mysql = require("mysql2/promise");

function loadEnvLocal() {
  const envPath = path.join(process.cwd(), ".env.local");
  if (!fs.existsSync(envPath)) return;
  const content = fs.readFileSync(envPath, "utf8");
  for (const line of content.split("\n")) {
    const trimmed = line.trim();
    if (!trimmed || trimmed.startsWith("#")) continue;
    const idx = trimmed.indexOf("=");
    if (idx === -1) continue;
    const key = trimmed.slice(0, idx).trim();
    const value = trimmed.slice(idx + 1).trim();
    if (!(key in process.env)) process.env[key] = value;
  }
}

async function main() {
  loadEnvLocal();

  const connection = await mysql.createConnection({
    host: process.env.DB_HOST || "127.0.0.1",
    port: Number(process.env.DB_PORT || 3306),
    user: process.env.DB_USER || "root",
    password: process.env.DB_PASSWORD || "",
    multipleStatements: true,
  });

  const schema = fs.readFileSync(path.join(__dirname, "schema.sql"), "utf8");
  const seed = fs.readFileSync(path.join(__dirname, "seed.sql"), "utf8");

  console.log("Menjalankan schema.sql ...");
  await connection.query(schema);

  console.log("Menjalankan seed.sql (32 siswa) ...");
  await connection.query(seed);

  console.log("Selesai. Database `xi_tkj_3` siap dipakai.");
  await connection.end();
}

main().catch((err) => {
  console.error("Gagal menjalankan seeder:", err.message);
  process.exit(1);
});
