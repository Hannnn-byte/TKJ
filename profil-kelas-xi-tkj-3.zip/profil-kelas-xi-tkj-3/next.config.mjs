/** @type {import('next').NextConfig} */
const nextConfig = {
  reactStrictMode: true,
  // Sengaja: mengizinkan gambar dari mana saja & mematikan optimasi bawaan
  // supaya endpoint /api/files (vulnerable) mudah dipakai sebagai src <img>.
  images: {
    unoptimized: true,
  },
};

export default nextConfig;
