#!/usr/bin/env bash
# =================================================================
#  deploy.sh — Deploy LAB Keamanan Web "Profil XI TKJ 3"
#  Target OS : CentOS Stream 10 (juga kompatibel dengan Stream 9)
#  Kebutuhan : akses root (sudo), koneksi internet untuk install
#
#  ⚠  PERINGATAN: Aplikasi ini SENGAJA rentan (SQLi, XSS, Path
#     Traversal). Jalankan HANYA di jaringan lab terisolasi!
# =================================================================

set -Eeuo pipefail

# ── Warna terminal ──────────────────────────────────────────────
RED='\033[0;31m'; GREEN='\033[0;32m'; YELLOW='\033[1;33m'
CYAN='\033[0;36m'; BOLD='\033[1m'; NC='\033[0m'

log()  { echo -e "${GREEN}[+]${NC} $*"; }
info() { echo -e "${CYAN}[i]${NC} $*"; }
warn() { echo -e "${YELLOW}[!]${NC} $*"; }
err()  { echo -e "${RED}[✗]${NC} $*"; exit 1; }
step() { echo -e "\n${BOLD}${CYAN}══ $* ${NC}"; }

# ── Variabel konfigurasi (ubah sesuai kebutuhan) ───────────────
DB_PASSWORD="${DB_PASSWORD:-labpassword}"   # password root MariaDB
APP_PORT="${APP_PORT:-3000}"                # port Next.js app
PROJECT_DIR="${PROJECT_DIR:-/opt/profil-xi-tkj3}"  # dir instalasi
ZIP_NAME="profil-kelas-xi-tkj-3.zip"       # nama file zip proyek

# ── Deteksi root ────────────────────────────────────────────────
[[ $EUID -ne 0 ]] && err "Jalankan script ini sebagai root atau dengan sudo."

# ── Banner ──────────────────────────────────────────────────────
echo -e "${BOLD}${GREEN}"
cat << 'EOF'
 ____  ____  _____  _  __  ____
|  _ \|  _ \|  _  || |/ / |___ \
| | | | |_) || |_| || ' /   __) |
| |_| |  _ < |  _  || . \  / __/
|____/|_| \_\|_| |_||_|\_\|_____|
   XI TKJ 3 — SMK Telkom Malang
   🔓 Lab Keamanan Web — Docker Deploy
EOF
echo -e "${NC}"
warn "Aplikasi ini SENGAJA rentan. Gunakan di jaringan lab lokal saja!"
echo ""

# ── Fungsi: deteksi versi OS ────────────────────────────────────
get_centos_version() {
    if [[ -f /etc/centos-release ]]; then
        grep -oP '\d+' /etc/centos-release | head -1
    elif [[ -f /etc/os-release ]]; then
        source /etc/os-release
        echo "${VERSION_ID%%.*}"
    else
        echo "0"
    fi
}

# ── Fungsi: install Docker CE ───────────────────────────────────
install_docker() {
    step "Instalasi Docker CE"

    local ver
    ver=$(get_centos_version)
    info "Terdeteksi CentOS/RHEL versi: ${ver}"

    if command -v docker &>/dev/null; then
        log "Docker sudah terpasang: $(docker --version)"
        return 0
    fi

    log "Menghapus paket podman/moby lama yang mungkin konflik..."
    dnf remove -y docker docker-client docker-client-latest \
        docker-common docker-latest docker-latest-logrotate \
        docker-logrotate docker-engine podman runc \
        2>/dev/null || true

    log "Menambahkan repo Docker CE..."
    dnf install -y dnf-plugins-core

    # Coba repo CentOS dengan $releasever asli dulu
    local repo_url="https://download.docker.com/linux/centos/docker-ce.repo"
    dnf config-manager --add-repo "$repo_url"

    # CentOS 10 Stream: docker-ce repo mungkin belum punya entry
    # '$releasever = 10'. Kalau gagal, paksa pakai versi 9 sebagai base.
    if ! dnf list docker-ce &>/dev/null 2>&1; then
        warn "Repo CentOS ${ver} belum tersedia. Memaksa releasever=9..."
        sed -i 's|\$releasever|9|g' /etc/yum.repos.d/docker-ce.repo
    fi

    log "Menginstall docker-ce, docker-ce-cli, containerd.io, compose plugin..."
    dnf install -y \
        docker-ce \
        docker-ce-cli \
        containerd.io \
        docker-buildx-plugin \
        docker-compose-plugin

    log "Mengaktifkan & menjalankan service Docker..."
    systemctl enable --now docker

    log "Memverifikasi Docker..."
    docker version --format 'Client: {{.Client.Version}} | Server: {{.Server.Version}}'
    log "Docker CE berhasil terpasang."
}

# ── Fungsi: konfigurasi firewall ────────────────────────────────
configure_firewall() {
    step "Konfigurasi Firewall"

    if ! systemctl is-active --quiet firewalld; then
        info "firewalld tidak berjalan, melewati konfigurasi firewall."
        return 0
    fi

    log "Membuka port ${APP_PORT}/tcp untuk aplikasi..."
    firewall-cmd --permanent --add-port="${APP_PORT}/tcp"

    log "Reload firewalld..."
    firewall-cmd --reload

    log "Port ${APP_PORT} sudah dibuka."
}

# ── Fungsi: siapkan file proyek ─────────────────────────────────
setup_project() {
    step "Menyiapkan Direktori Proyek"

    # Cari file zip proyek di direktori yang sama dengan script ini
    local script_dir
    script_dir="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
    local zip_path="${script_dir}/${ZIP_NAME}"

    if [[ ! -f "$zip_path" ]]; then
        # Coba cari di direktori kerja saat ini
        zip_path="${PWD}/${ZIP_NAME}"
        [[ ! -f "$zip_path" ]] && err "File ${ZIP_NAME} tidak ditemukan.
Taruh file zip proyek di direktori yang sama dengan deploy.sh lalu jalankan ulang."
    fi

    info "File proyek : $zip_path"
    info "Direktori  : $PROJECT_DIR"

    if [[ -d "$PROJECT_DIR" ]]; then
        warn "Direktori $PROJECT_DIR sudah ada."
        read -rp "  Timpa ulang? [y/N] " confirm
        [[ "$confirm" =~ ^[Yy]$ ]] || { info "Deploy dibatalkan."; exit 0; }
        # Hentikan container lama jika masih berjalan
        if [[ -f "${PROJECT_DIR}/docker-compose.yml" ]]; then
            (cd "$PROJECT_DIR" && docker compose down 2>/dev/null || true)
        fi
        rm -rf "$PROJECT_DIR"
    fi

    log "Mengekstrak $ZIP_NAME ke $PROJECT_DIR ..."
    mkdir -p "$PROJECT_DIR"

    # unzip -o: overwrite; -q: diam; -d: dir tujuan
    if ! command -v unzip &>/dev/null; then
        dnf install -y unzip
    fi
    unzip -q "$zip_path" -d "$(dirname "$PROJECT_DIR")"

    # Zip menghasilkan subfolder 'profil-kelas-xi-tkj-3/' di dalamnya;
    # pastikan PROJECT_DIR menunjuk ke subfolder tersebut.
    local inner_dir
    inner_dir=$(unzip -Z1 "$zip_path" | head -1 | cut -d/ -f1)
    local extracted_path
    extracted_path="$(dirname "$PROJECT_DIR")/${inner_dir}"

    if [[ "$extracted_path" != "$PROJECT_DIR" ]]; then
        mv "$extracted_path" "$PROJECT_DIR"
    fi

    log "Proyek berhasil diekstrak ke $PROJECT_DIR"
}

# ── Fungsi: setup file environment ──────────────────────────────
setup_env() {
    step "Membuat File .env.local"

    local env_file="${PROJECT_DIR}/.env.local"
    if [[ -f "$env_file" ]]; then
        info ".env.local sudah ada, melewati pembuatan."
        return 0
    fi

    cat > "$env_file" << EOF
# Dibuat otomatis oleh deploy.sh — $(date)
DB_HOST=db
DB_PORT=3306
DB_USER=root
DB_PASSWORD=${DB_PASSWORD}
DB_NAME=xi_tkj_3
STUDENT_PHOTO_DIR=/app/public/students
EOF
    log ".env.local dibuat."
}

# ── Fungsi: salin file docker ke project ────────────────────────
copy_docker_files() {
    step "Menyalin File Docker ke Proyek"

    local script_dir
    script_dir="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

    for f in Dockerfile docker-compose.yml .dockerignore; do
        local src="${script_dir}/${f}"
        local dst="${PROJECT_DIR}/${f}"
        if [[ -f "$src" ]]; then
            cp "$src" "$dst"
            log "Disalin: $f"
        else
            warn "${f} tidak ditemukan di $script_dir, dilewati."
        fi
    done
}

# ── Fungsi: build & jalankan containers ─────────────────────────
docker_up() {
    step "Build & Menjalankan Container"

    cd "$PROJECT_DIR"

    # Eksport DB_PASSWORD supaya docker-compose bisa pakai ${DB_PASSWORD}
    export DB_PASSWORD

    log "Menjalankan docker compose build (mungkin butuh beberapa menit)..."
    docker compose build --no-cache

    log "Menjalankan semua service..."
    docker compose up -d

    log "Menunggu container sehat..."
    local max=60 elapsed=0
    while ! docker compose ps | grep -q "healthy"; do
        sleep 3
        elapsed=$((elapsed + 3))
        echo -n "."
        [[ $elapsed -ge $max ]] && { echo ""; warn "Timeout menunggu container sehat. Cek log: docker compose logs db"; break; }
    done
    echo ""

    log "Status container:"
    docker compose ps
}

# ── Fungsi: tampilkan info akses ─────────────────────────────────
show_info() {
    step "Deployment Selesai"

    # Dapatkan IP non-loopback pertama
    local host_ip
    host_ip=$(ip -4 addr show scope global | grep -oP '(?<=inet\s)\d+(\.\d+){3}' | head -1 || echo "127.0.0.1")

    echo -e "${BOLD}${GREEN}"
    echo "  ┌─────────────────────────────────────────────────────┐"
    echo "  │  Akses Aplikasi                                     │"
    echo "  │                                                     │"
    printf "  │  Lokal   : http://localhost:%-26s│\n" "${APP_PORT}"
    printf "  │  Jaringan: http://%-32s│\n" "${host_ip}:${APP_PORT}"
    echo "  │                                                     │"
    echo "  │  Perintah berguna:                                  │"
    echo "  │    docker compose logs -f app   (log Next.js)       │"
    echo "  │    docker compose logs -f db    (log MariaDB)       │"
    echo "  │    docker compose down          (stop semua)         │"
    echo "  │    docker compose restart app   (restart Next.js)   │"
    echo "  │                                                     │"
    printf "  │  Project dir: %-37s│\n" "$PROJECT_DIR"
    echo "  └─────────────────────────────────────────────────────┘"
    echo -e "${NC}"

    echo -e "${YELLOW}  ⚠  Ingat: aplikasi ini sengaja rentan (SQLi/XSS/PathTraversal).${NC}"
    echo -e "${YELLOW}     Gunakan hanya di jaringan lab terisolasi!${NC}\n"
}

# ── Entri utama ─────────────────────────────────────────────────
main() {
    install_docker
    configure_firewall
    setup_project
    setup_env
    copy_docker_files
    docker_up
    show_info
}

main "$@"
