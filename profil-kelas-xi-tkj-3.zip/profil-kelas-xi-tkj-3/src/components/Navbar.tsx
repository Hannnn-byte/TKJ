import Link from "next/link";

export default function Navbar() {
  return (
    <header className="sticky top-0 z-40 border-b border-term-line bg-term-bg/85 backdrop-blur">
      <div className="mx-auto flex max-w-5xl items-center justify-between px-5 py-3 text-sm">
        <Link href="/" className="text-term-green text-glow font-semibold tracking-tight">
          guest@xi-tkj-3<span className="text-term-muted">:</span>
          <span className="text-term-cyan">~</span>
          <span className="text-term-muted">$</span>
        </Link>
        <nav className="flex items-center gap-5 text-term-muted">
          <Link href="/" className="link-underline">
            ./home
          </Link>
          <Link href="/students" className="link-underline">
            ./siswa
          </Link>
        </nav>
      </div>
    </header>
  );
}
