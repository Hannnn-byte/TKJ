import Link from "next/link";

export type StudentSummary = {
  id: number;
  foto: string;
  nama_lengkap: string;
  nama_panggilan: string;
  keahlian: string;
};

export default function StudentCard({ student }: { student: StudentSummary }) {
  return (
    <div className="flex flex-col overflow-hidden rounded border border-term-line bg-term-panel/70 transition-colors hover:border-term-green-dim">
      <div className="aspect-square w-full overflow-hidden bg-black/40">
        {/* Foto dimuat lewat endpoint /api/files (lihat README soal celah Path Traversal) */}
        <img
          src={`/api/files?path=${encodeURIComponent(student.foto || "placeholder.svg")}`}
          alt={student.nama_lengkap}
          className="h-full w-full object-cover"
        />
      </div>
      <div className="flex flex-1 flex-col gap-1 p-4">
        <p className="truncate text-sm font-semibold text-term-fg">
          {student.nama_lengkap}
        </p>
        <p className="truncate text-xs text-term-muted">
          panggilan: {student.nama_panggilan}
        </p>
        <p className="mt-1 truncate text-xs text-term-cyan">{student.keahlian}</p>
        <Link
          href={`/students/${student.id}`}
          className="prompt mt-3 inline-flex w-fit items-center rounded border border-term-green-dim px-3 py-1.5 text-xs text-term-green transition-colors hover:bg-term-green/10"
        >
          <span>lihat --profil</span>
        </Link>
      </div>
    </div>
  );
}
