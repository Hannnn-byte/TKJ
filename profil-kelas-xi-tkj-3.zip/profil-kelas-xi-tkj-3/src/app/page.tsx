import Link from "next/link";
import TerminalWindow from "@/components/TerminalWindow";
import { getPool } from "@/lib/db";

export const dynamic = "force-dynamic";

async function getStudentCount(): Promise<number> {
  try {
    const pool = getPool();
    const [rows]: any = await pool.query(
      `SELECT COUNT(*) AS total FROM students`
    );
    return rows?.[0]?.total ?? 0;
  } catch {
    return 32;
  }
}

export default async function HomePage() {
  const total = await getStudentCount();

  return (
    <div className="space-y-8">
      <TerminalWindow title="guest@xi-tkj-3:~$ cat kelas.json">
        <p className="prompt text-term-muted">whoami --kelas</p>
        <h1 className="mt-2 text-3xl font-semibold text-term-green text-glow sm:text-4xl">
          XI TKJ 3
        </h1>
        <p className="mt-1 text-term-fg">SMK Telkom Malang</p>

        <div className="mt-6 grid gap-6 sm:grid-cols-[220px_1fr]">
          <div className="overflow-hidden rounded border border-term-line bg-black/40">
            <img
              src="/api/files?path=kelas-dummy.svg"
              alt="Foto kelas XI TKJ 3"
              className="h-full w-full object-cover"
            />
          </div>

          <div className="space-y-4">
            <p className="text-sm leading-relaxed text-term-fg/90">
              Kelas XI TKJ 3 adalah kelas kompetensi keahlian{" "}
              <span className="text-term-cyan">Teknik Komputer dan Jaringan</span>{" "}
              di SMK Telkom Malang, berisi 32 siswa yang belajar merancang,
              membangun, dan mengamankan infrastruktur jaringan — mulai dari
              routing, server, fiber optik, hingga dasar-dasar keamanan
              siber. Website ini sekaligus dipakai sebagai{" "}
              <span className="text-term-amber">
                laboratorium praktikum keamanan aplikasi web
              </span>
              .
            </p>

            <div className="flex flex-wrap items-center gap-4 text-sm">
              <div className="rounded border border-term-line bg-black/30 px-4 py-2">
                <span className="block text-2xl font-semibold text-term-green">
                  {total}
                </span>
                <span className="text-xs text-term-muted">total siswa</span>
              </div>

              <Link
                href="/students"
                className="inline-flex items-center gap-2 rounded border border-term-green-dim bg-term-green/10 px-4 py-2 text-term-green shadow-glow transition-colors hover:bg-term-green/20"
              >
                <span className="prompt" />
                <span>cd ./daftar-siswa</span>
              </Link>
            </div>
          </div>
        </div>
      </TerminalWindow>

      <TerminalWindow title="guest@xi-tkj-3:~$ cat README.lab">
        <ul className="space-y-2 text-sm text-term-fg/90">
          <li>
            <span className="text-term-amber">01.</span> Halaman{" "}
            <code className="text-term-cyan">/students</code> menampilkan
            seluruh siswa dan fitur pencarian nama.
          </li>
          <li>
            <span className="text-term-amber">02.</span> Setiap profil siswa
            punya form untuk mengedit "Deskripsi Diri" (CRUD).
          </li>
          <li>
            <span className="text-term-amber">03.</span> Aplikasi ini{" "}
            <span className="text-term-red">sengaja dibuat rentan</span>{" "}
            (SQL Injection, XSS, Path Traversal) untuk praktikum pentest —
            lihat README proyek untuk detail lengkap.
          </li>
        </ul>
      </TerminalWindow>
    </div>
  );
}
