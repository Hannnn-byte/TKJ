import Link from "next/link";
import TerminalWindow from "@/components/TerminalWindow";

export default function NotFound() {
  return (
    <TerminalWindow title="guest@xi-tkj-3:~$ ./halaman.sh">
      <p className="text-term-red">bash: 404 — halaman atau siswa tidak ditemukan</p>
      <Link href="/" className="link-underline mt-4 inline-block text-sm text-term-muted">
        cd ~
      </Link>
    </TerminalWindow>
  );
}
