import { NextRequest, NextResponse } from "next/server";
import { getPool } from "@/lib/db";

/**
 * GET /api/search?nama=...
 *
 * ============================================================
 *  CELAH LAB #1 — SQL INJECTION (SENGAJA, JANGAN DIPERBAIKI DI SINI)
 * ============================================================
 * Endpoint ini SENGAJA membangun query dengan string concatenation
 * mentah dari input pengguna (req.nextUrl.searchParams), TANPA
 * prepared statement dan TANPA validasi/escaping input apa pun,
 * sesuai spesifikasi lab pentest.
 *
 * Contoh payload untuk didemonstrasikan siswa (di kolom "nama"):
 *   ' OR '1'='1
 *   ' UNION SELECT id,foto,nama_lengkap,nama_panggilan,kelas,keahlian,skill,hobi,cita_cita,deskripsi,1,1 FROM students -- -
 *
 * Untuk versi PRODUKSI/aman, ganti implementasi di bawah dengan:
 *   pool.query('SELECT ... WHERE nama_lengkap LIKE ?', [`%${nama}%`])
 * yaitu persis pola yang sudah dipakai di /api/students/[id] (GET).
 */
export async function GET(req: NextRequest) {
  const nama = req.nextUrl.searchParams.get("nama") ?? "";

  try {
    const pool = getPool();

    // VULNERABLE: string concatenation langsung ke dalam SQL.
    const query = `SELECT * FROM students WHERE nama_lengkap LIKE '%${nama}%'`;

    // pool.query() dengan satu argumen string akan mengeksekusi query
    // tersebut apa adanya (tidak ada parameter binding di sini).
    const [rows] = await pool.query(query);

    return NextResponse.json({
      data: rows,
      // query mentah ikut dikembalikan supaya siswa lab bisa melihat
      // persis payload yang dieksekusi ke database — HANYA untuk lab.
      debug_query: query,
    });
  } catch (err: any) {
    // Pesan error database ditampilkan apa adanya (verbose error) — ini
    // juga disengaja, karena error SQL yang bocor mempermudah teknik
    // enumerasi error-based SQL injection saat praktikum.
    return NextResponse.json(
      { error: "Query gagal dieksekusi", detail: String(err?.message || err) },
      { status: 500 }
    );
  }
}
