import { NextRequest, NextResponse } from "next/server";
import { getPool } from "@/lib/db";

// GET /api/students/:id -> detail satu siswa
export async function GET(
  _req: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const pool = getPool();
    const [rows]: any = await pool.query(
      `SELECT * FROM students WHERE id = ? LIMIT 1`,
      [params.id]
    );
    if (!rows || rows.length === 0) {
      return NextResponse.json({ error: "Siswa tidak ditemukan" }, { status: 404 });
    }
    return NextResponse.json({ data: rows[0] });
  } catch (err: any) {
    return NextResponse.json(
      { error: "Gagal mengambil data siswa", detail: String(err?.message || err) },
      { status: 500 }
    );
  }
}

// PUT /api/students/:id -> update data siswa (CRUD: Update)
//
// CATATAN LAB — CELAH XSS (Stored) ADA DI SINI:
// Field `deskripsi` diterima dan disimpan APA ADANYA ke database, tanpa
// sanitasi/escaping HTML sama sekali. Payload seperti
// `<script>alert('XSS')</script>` akan tersimpan utuh, lalu dieksekusi
// saat halaman profil siswa merendernya lewat `dangerouslySetInnerHTML`
// (lihat src/app/students/[id]/page.tsx). Ini disengaja untuk praktikum.
export async function PUT(
  req: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const body = await req.json();
    const {
      foto,
      nama_lengkap,
      nama_panggilan,
      kelas,
      keahlian,
      skill,
      hobi,
      cita_cita,
      deskripsi, // <-- disimpan mentah, sengaja tidak disanitasi (Stored XSS)
    } = body || {};

    const pool = getPool();

    // Query update memakai prepared statement (`?`) — bukan di sinilah
    // letak celah SQLi labnya (itu ada di /api/search). Namun karena
    // `deskripsi` tidak pernah dibersihkan dari tag HTML/JS sebelum
    // disimpan, nilai berbahaya tetap lolos ke database.
    const [result]: any = await pool.query(
      `UPDATE students SET
        foto = COALESCE(?, foto),
        nama_lengkap = COALESCE(?, nama_lengkap),
        nama_panggilan = COALESCE(?, nama_panggilan),
        kelas = COALESCE(?, kelas),
        keahlian = COALESCE(?, keahlian),
        skill = COALESCE(?, skill),
        hobi = COALESCE(?, hobi),
        cita_cita = COALESCE(?, cita_cita),
        deskripsi = COALESCE(?, deskripsi)
       WHERE id = ?`,
      [
        foto ?? null,
        nama_lengkap ?? null,
        nama_panggilan ?? null,
        kelas ?? null,
        keahlian ?? null,
        skill ?? null,
        hobi ?? null,
        cita_cita ?? null,
        deskripsi ?? null,
        params.id,
      ]
    );

    if (result.affectedRows === 0) {
      return NextResponse.json({ error: "Siswa tidak ditemukan" }, { status: 404 });
    }
    return NextResponse.json({ ok: true });
  } catch (err: any) {
    return NextResponse.json(
      { error: "Gagal memperbarui data siswa", detail: String(err?.message || err) },
      { status: 500 }
    );
  }
}

// DELETE /api/students/:id -> hapus siswa (CRUD: Delete)
export async function DELETE(
  _req: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const pool = getPool();
    const [result]: any = await pool.query(`DELETE FROM students WHERE id = ?`, [
      params.id,
    ]);
    if (result.affectedRows === 0) {
      return NextResponse.json({ error: "Siswa tidak ditemukan" }, { status: 404 });
    }
    return NextResponse.json({ ok: true });
  } catch (err: any) {
    return NextResponse.json(
      { error: "Gagal menghapus siswa", detail: String(err?.message || err) },
      { status: 500 }
    );
  }
}
