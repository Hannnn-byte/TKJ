import { NextRequest, NextResponse } from "next/server";
import { getPool } from "@/lib/db";

// GET /api/students -> daftar seluruh siswa
// Route ini AMAN (prepared statement / tanpa input dinamis). Endpoint yang
// sengaja dibuat rentan untuk pencarian ada di /api/search (lihat route itu).
export async function GET() {
  try {
    const pool = getPool();
    const [rows] = await pool.query(
      `SELECT id, foto, nama_lengkap, nama_panggilan, kelas, keahlian, skill, hobi, cita_cita
       FROM students
       ORDER BY nama_lengkap ASC`
    );
    return NextResponse.json({ data: rows });
  } catch (err: any) {
    return NextResponse.json(
      { error: "Gagal mengambil data siswa", detail: String(err?.message || err) },
      { status: 500 }
    );
  }
}

// POST /api/students -> tambah siswa baru (CRUD: Create)
// Tetap memakai prepared statement (`?`) sehingga bagian ini TIDAK
// membawa celah SQL Injection — celah SQLi khusus disisipkan pada
// fitur pencarian sesuai spesifikasi lab.
export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const {
      foto = "placeholder.svg",
      nama_lengkap,
      nama_panggilan,
      kelas = "XI TKJ 3",
      keahlian,
      skill,
      hobi,
      cita_cita,
      deskripsi = "",
    } = body || {};

    if (!nama_lengkap || !nama_panggilan) {
      return NextResponse.json(
        { error: "nama_lengkap dan nama_panggilan wajib diisi" },
        { status: 400 }
      );
    }

    const pool = getPool();
    const [result]: any = await pool.query(
      `INSERT INTO students
        (foto, nama_lengkap, nama_panggilan, kelas, keahlian, skill, hobi, cita_cita, deskripsi)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`,
      [foto, nama_lengkap, nama_panggilan, kelas, keahlian, skill, hobi, cita_cita, deskripsi]
    );

    return NextResponse.json({ id: result.insertId }, { status: 201 });
  } catch (err: any) {
    return NextResponse.json(
      { error: "Gagal menambah siswa", detail: String(err?.message || err) },
      { status: 500 }
    );
  }
}
