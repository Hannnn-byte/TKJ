import { NextRequest, NextResponse } from "next/server";
import fs from "fs";
import path from "path";

/**
 * GET /api/files?path=<nama_file>
 *
 * ============================================================
 *  CELAH LAB #2 — PATH TRAVERSAL (SENGAJA, JANGAN DIPERBAIKI DI SINI)
 * ============================================================
 * Endpoint ini dipakai untuk memuat foto siswa dari
 * STUDENT_PHOTO_DIR (default: public/students). Parameter `path`
 * dari pengguna SENGAJA digabung langsung ke path direktori memakai
 * fs.readFileSync, TANPA:
 *   - validasi / whitelist nama file
 *   - filter karakter "../" atau "..\"
 *   - path.normalize + pengecekan "masih di dalam base dir"
 * sesuai spesifikasi lab pentest.
 *
 * Contoh payload untuk didemonstrasikan siswa:
 *   /api/files?path=../../../../etc/passwd
 *   /api/files?path=..%2f..%2f..%2fpackage.json
 *
 * Untuk versi PRODUKSI/aman, gunakan pola:
 *   const safeName = path.basename(userInput);
 *   const resolved = path.resolve(baseDir, safeName);
 *   if (!resolved.startsWith(path.resolve(baseDir))) return 400;
 */
export async function GET(req: NextRequest) {
  const requestedPath = req.nextUrl.searchParams.get("path") ?? "placeholder.svg";

  const baseDir =
    process.env.STUDENT_PHOTO_DIR || path.join(process.cwd(), "public", "students");

  // VULNERABLE: concatenation mentah, tidak ada sanitasi "../" sama sekali.
  const targetPath = path.join(baseDir, requestedPath);

  try {
    // VULNERABLE: fs.readFileSync membaca file apa pun yang bisa dijangkau
    // oleh proses Node ini, termasuk file di luar baseDir bila
    // requestedPath berisi "../".
    const fileBuffer = fs.readFileSync(targetPath);

    const ext = path.extname(targetPath).toLowerCase();
    const mimeMap: Record<string, string> = {
      ".png": "image/png",
      ".jpg": "image/jpeg",
      ".jpeg": "image/jpeg",
      ".svg": "image/svg+xml",
      ".webp": "image/webp",
      ".gif": "image/gif",
    };
    const contentType = mimeMap[ext] || "application/octet-stream";

    return new NextResponse(fileBuffer, {
      status: 200,
      headers: { "Content-Type": contentType },
    });
  } catch (err: any) {
    return NextResponse.json(
      { error: "File tidak ditemukan", path_dicoba: targetPath, detail: String(err?.message || err) },
      { status: 404 }
    );
  }
}
