"use client";

import { useState } from "react";

/**
 * ============================================================
 *  CELAH LAB #3 — CROSS-SITE SCRIPTING / XSS (SENGAJA)
 * ============================================================
 * Deskripsi diri diambil dari state (hasil dari database, tersimpan
 * mentah lewat PUT /api/students/:id) lalu dirender memakai
 * `dangerouslySetInnerHTML` TANPA sanitasi DOM apa pun (tidak memakai
 * DOMPurify atau sejenisnya). Jika seorang siswa menyimpan deskripsi
 * berisi, misalnya, `<script>alert('XSS')</script>` atau
 * `<img src=x onerror=alert(1)>`, payload tersebut akan tereksekusi
 * setiap kali halaman profil ini dibuka oleh siapa pun — inilah
 * contoh Stored XSS untuk praktikum.
 */
export default function ProfileClient({
  id,
  initialDeskripsi,
}: {
  id: number;
  initialDeskripsi: string;
}) {
  const [deskripsi, setDeskripsi] = useState(initialDeskripsi || "");
  const [draft, setDraft] = useState(initialDeskripsi || "");
  const [editing, setEditing] = useState(false);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState<string | null>(null);

  async function handleSave() {
    setSaving(true);
    setError(null);
    try {
      const res = await fetch(`/api/students/${id}`, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        // deskripsi dikirim persis seperti yang diketik pengguna —
        // tidak ada escaping/sanitasi di sisi client maupun server.
        body: JSON.stringify({ deskripsi: draft }),
      });
      if (!res.ok) {
        const json = await res.json().catch(() => ({}));
        throw new Error(json?.detail || json?.error || "Gagal menyimpan.");
      }
      setDeskripsi(draft);
      setEditing(false);
    } catch (e: any) {
      setError(e?.message || "Gagal menyimpan deskripsi.");
    } finally {
      setSaving(false);
    }
  }

  return (
    <div className="space-y-3">
      <div className="flex items-center justify-between">
        <p className="prompt text-xs text-term-muted">cat deskripsi_diri.txt</p>
        {!editing && (
          <button
            onClick={() => {
              setDraft(deskripsi);
              setEditing(true);
            }}
            className="rounded border border-term-line px-3 py-1 text-xs text-term-muted transition-colors hover:border-term-green-dim hover:text-term-green"
          >
            edit --deskripsi
          </button>
        )}
      </div>

      {editing ? (
        <div className="space-y-3">
          <textarea
            value={draft}
            onChange={(e) => setDraft(e.target.value)}
            rows={6}
            className="w-full rounded border border-term-line bg-black/40 p-3 text-sm text-term-fg outline-none focus:border-term-green-dim"
            placeholder="Tulis deskripsi diri kamu di sini..."
          />
          <div className="flex gap-2">
            <button
              onClick={handleSave}
              disabled={saving}
              className="rounded border border-term-green-dim bg-term-green/10 px-4 py-1.5 text-xs text-term-green hover:bg-term-green/20 disabled:opacity-50"
            >
              {saving ? "menyimpan..." : "save --deskripsi"}
            </button>
            <button
              onClick={() => {
                setEditing(false);
                setError(null);
              }}
              className="rounded border border-term-line px-4 py-1.5 text-xs text-term-muted hover:text-term-fg"
            >
              batal
            </button>
          </div>
          {error && <p className="text-xs text-term-red">{error}</p>}
        </div>
      ) : (
        <div
          className="prose-invert min-h-[3rem] rounded border border-term-line bg-black/20 p-4 text-sm leading-relaxed text-term-fg/90"
          // VULNERABLE (sengaja): tidak ada sanitasi sebelum dirender.
          dangerouslySetInnerHTML={{ __html: deskripsi || "<i>Belum ada deskripsi.</i>" }}
        />
      )}
    </div>
  );
}
