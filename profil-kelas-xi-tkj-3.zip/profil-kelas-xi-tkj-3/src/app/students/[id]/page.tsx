import Link from "next/link";
import { notFound } from "next/navigation";
import TerminalWindow from "@/components/TerminalWindow";
import ProfileClient from "./ProfileClient";
import { getPool, Student } from "@/lib/db";

export const dynamic = "force-dynamic";

async function getStudent(id: string): Promise<Student | null> {
  const pool = getPool();
  const [rows]: any = await pool.query(
    `SELECT * FROM students WHERE id = ? LIMIT 1`,
    [id]
  );
  return rows?.[0] ?? null;
}

export default async function StudentProfilePage({
  params,
}: {
  params: { id: string };
}) {
  const student = await getStudent(params.id);
  if (!student) notFound();

  const fields: Array<[string, string]> = [
    ["nama_panggilan", student.nama_panggilan],
    ["kelas", student.kelas],
    ["keahlian", student.keahlian],
    ["skill", student.skill],
    ["hobi", student.hobi],
    ["cita_cita", student.cita_cita],
  ];

  return (
    <div className="space-y-6">
      <Link href="/students" className="link-underline text-xs text-term-muted">
        cd ..
      </Link>

      <TerminalWindow title={`guest@xi-tkj-3:~$ cat siswa/${student.id}.json`}>
        <div className="grid gap-6 sm:grid-cols-[180px_1fr]">
          <div className="h-44 w-44 overflow-hidden rounded border border-term-line bg-black/40">
            <img
              src={`/api/files?path=${encodeURIComponent(student.foto || "placeholder.svg")}`}
              alt={student.nama_lengkap}
              className="h-full w-full object-cover"
            />
          </div>

          <div>
            <h1 className="text-2xl font-semibold text-term-green text-glow">
              {student.nama_lengkap}
            </h1>
            <dl className="mt-4 grid grid-cols-1 gap-x-6 gap-y-2 text-sm sm:grid-cols-2">
              {fields.map(([label, value]) => (
                <div key={label} className="flex gap-2">
                  <dt className="w-28 shrink-0 text-term-muted">{label}</dt>
                  <dd className="text-term-fg/90">{value}</dd>
                </div>
              ))}
            </dl>
          </div>
        </div>
      </TerminalWindow>

      <TerminalWindow title="guest@xi-tkj-3:~$ nano deskripsi_diri.txt">
        <ProfileClient id={student.id} initialDeskripsi={student.deskripsi || ""} />
      </TerminalWindow>
    </div>
  );
}
