"use client";

import { useEffect, useState, FormEvent } from "react";
import TerminalWindow from "@/components/TerminalWindow";
import StudentCard, { StudentSummary } from "@/components/StudentCard";

export default function StudentsPage() {
  const [allStudents, setAllStudents] = useState<StudentSummary[]>([]);
  const [results, setResults] = useState<StudentSummary[] | null>(null);
  const [query, setQuery] = useState("");
  const [debugQuery, setDebugQuery] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);
  const [searching, setSearching] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    fetch("/api/students")
      .then((res) => res.json())
      .then((json) => setAllStudents(json.data || []))
      .catch(() => setError("Gagal memuat daftar siswa."))
      .finally(() => setLoading(false));
  }, []);

  async function handleSearch(e: FormEvent) {
    e.preventDefault();
    setSearching(true);
    setError(null);
    try {
      // NOTE LAB: endpoint /api/search ini SENGAJA rentan SQL Injection
      // (raw string concatenation di backend). Coba masukkan payload
      // seperti:  ' OR '1'='1
      const res = await fetch(`/api/search?nama=${encodeURIComponent(query)}`);
      const json = await res.json();
      if (!res.ok) {
        setError(json?.detail || json?.error || "Query gagal dieksekusi.");
        setResults([]);
        setDebugQuery(null);
        return;
      }
      setResults(json.data || []);
      setDebugQuery(json.debug_query || null);
    } catch {
      setError("Gagal terhubung ke server pencarian.");
    } finally {
      setSearching(false);
    }
  }

  function resetSearch() {
    setQuery("");
    setResults(null);
    setDebugQuery(null);
    setError(null);
  }

  const shown = results ?? allStudents;

  return (
    <div className="space-y-6">
      <TerminalWindow title="guest@xi-tkj-3:~$ ./cari-siswa.sh">
        <form onSubmit={handleSearch} className="flex flex-wrap items-center gap-3">
          <label className="prompt text-sm text-term-muted" htmlFor="nama">
            search --nama
          </label>
          <input
            id="nama"
            type="text"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="cth: Aang, Rahel, Intan ..."
            className="min-w-[220px] flex-1 rounded border border-term-line bg-black/40 px-3 py-2 text-sm text-term-fg outline-none focus:border-term-green-dim"
          />
          <button
            type="submit"
            disabled={searching}
            className="rounded border border-term-green-dim bg-term-green/10 px-4 py-2 text-sm text-term-green transition-colors hover:bg-term-green/20 disabled:opacity-50"
          >
            {searching ? "mencari..." : "grep -i"}
          </button>
          {results !== null && (
            <button
              type="button"
              onClick={resetSearch}
              className="rounded border border-term-line px-3 py-2 text-sm text-term-muted hover:text-term-fg"
            >
              reset
            </button>
          )}
        </form>

        {debugQuery && (
          <div className="mt-4 rounded border border-term-amber/40 bg-term-amber/5 p-3 text-xs">
            <p className="text-term-amber">
              [lab] query mentah yang dieksekusi ke MariaDB (endpoint ini
              sengaja rentan SQL Injection):
            </p>
            <code className="mt-1 block break-all text-term-fg/80">
              {debugQuery}
            </code>
          </div>
        )}

        {error && (
          <div className="mt-4 rounded border border-term-red/40 bg-term-red/5 p-3 text-xs text-term-red">
            {error}
          </div>
        )}
      </TerminalWindow>

      <TerminalWindow title={`guest@xi-tkj-3:~$ ls ./siswa (${shown.length})`}>
        {loading ? (
          <p className="text-sm text-term-muted">memuat data siswa...</p>
        ) : shown.length === 0 ? (
          <p className="text-sm text-term-muted">
            Tidak ada siswa yang cocok dengan pencarian.
          </p>
        ) : (
          <div className="grid grid-cols-2 gap-4 sm:grid-cols-3 md:grid-cols-4">
            {shown.map((s) => (
              <StudentCard key={s.id} student={s} />
            ))}
          </div>
        )}
      </TerminalWindow>
    </div>
  );
}
