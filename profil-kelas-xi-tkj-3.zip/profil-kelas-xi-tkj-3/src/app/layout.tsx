import type { Metadata } from "next";
import { JetBrains_Mono } from "next/font/google";
import "./globals.css";
import Navbar from "@/components/Navbar";

const jetbrainsMono = JetBrains_Mono({
  subsets: ["latin"],
  variable: "--font-mono",
  display: "swap",
});

export const metadata: Metadata = {
  title: "XI TKJ 3 // SMK Telkom Malang",
  description:
    "Profil Kelas XI TKJ 3 - SMK Telkom Malang. Lab praktikum keamanan web (sengaja rentan).",
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="id" className={jetbrainsMono.variable}>
      <body>
        <div className="crt-overlay" />
        <Navbar />
        <main className="mx-auto max-w-5xl px-5 py-10">{children}</main>
        <footer className="mx-auto max-w-5xl px-5 pb-10 pt-4 text-xs text-term-muted">
          <p>
            // XI TKJ 3 — SMK Telkom Malang · lab praktikum keamanan web, bukan
            aplikasi produksi.
          </p>
        </footer>
      </body>
    </html>
  );
}
