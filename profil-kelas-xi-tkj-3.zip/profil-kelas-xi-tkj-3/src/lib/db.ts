import mysql from "mysql2/promise";

/**
 * Connection pool ke MariaDB.
 *
 * CATATAN LAB: pool ini sendiri aman (pakai driver resmi mysql2).
 * Yang membuat aplikasi ini rentan SQL Injection adalah CARA beberapa
 * route memakainya — lihat src/app/api/search/route.ts, yang sengaja
 * menempelkan input pengguna langsung ke string query alih-alih
 * memakai placeholder `?` / prepared statement.
 */
let pool: mysql.Pool | undefined;

export function getPool() {
  if (!pool) {
    pool = mysql.createPool({
      host: process.env.DB_HOST || "127.0.0.1",
      port: Number(process.env.DB_PORT || 3306),
      user: process.env.DB_USER || "root",
      password: process.env.DB_PASSWORD || "",
      database: process.env.DB_NAME || "xi_tkj_3",
      waitForConnections: true,
      connectionLimit: 10,
      queueLimit: 0,
      dateStrings: true,
    });
  }
  return pool;
}

export type Student = {
  id: number;
  foto: string;
  nama_lengkap: string;
  nama_panggilan: string;
  kelas: string;
  keahlian: string;
  skill: string;
  hobi: string;
  cita_cita: string;
  deskripsi: string | null;
  created_at?: string;
  updated_at?: string;
};
