# Profil Kelas XI TKJ 3 — SMK Telkom Malang (Lab Keamanan Web)

Aplikasi full-stack Next.js (App Router) + Tailwind CSS + MariaDB, bertema
profil Kelas XI TKJ 3. Aplikasi ini **sengaja dibuat rentan** untuk dipakai
sebagai bahan praktikum penetration testing / web security.

> ⚠️ **PERINGATAN KERAS**
> Aplikasi ini mengandung celah keamanan yang **disisipkan dengan sengaja**
> (SQL Injection, XSS, Path Traversal). **JANGAN** deploy ke server yang
> terekspos ke internet publik, dan **JANGAN** pakai data/kredensial asli.
> Jalankan hanya di jaringan lab lokal/terisolasi (localhost, VM, atau
> container tanpa akses internet masuk).

---

## 1. Kebutuhan

- Node.js 18+
- MariaDB 10.x (atau MySQL yang kompatibel), berjalan lokal
- npm

## 2. Instalasi

```bash
npm install
cp .env.example .env.local
# sesuaikan DB_HOST / DB_USER / DB_PASSWORD / DB_NAME di .env.local
```

## 3. Membuat database & seeder

Opsi A — pakai CLI mysql:

```bash
mysql -u root -p < database/schema.sql
mysql -u root -p < database/seed.sql
```

Opsi B — pakai script Node (baca kredensial dari `.env.local`):

```bash
npm run seed
```

`schema.sql` membuat database `xi_tkj_3` dan tabel `students`.
`seed.sql` mengisi 32 data siswa awal (data keahlian/skill/hobi/cita-cita
berupa data dummy, hanya nama lengkap yang sesuai daftar kelas).

## 4. Menjalankan aplikasi

```bash
npm run dev
```

Buka `http://localhost:3000`.

---

## 5. Struktur halaman

| Halaman                | Deskripsi                                                        |
| ----------------------- | ----------------------------------------------------------------- |
| `/`                     | Beranda: nama kelas, sekolah, foto dummy, deskripsi, total siswa |
| `/students`             | Daftar siswa (card) + form pencarian nama                        |
| `/students/[id]`        | Profil lengkap siswa + form edit "Deskripsi Diri" (CRUD)         |

## 6. API routes

| Route                       | Method | Keterangan                                             |
| ---------------------------- | ------ | ------------------------------------------------------- |
| `/api/students`              | GET    | Daftar seluruh siswa (aman, prepared statement)         |
| `/api/students`              | POST   | Tambah siswa (aman, prepared statement)                 |
| `/api/students/:id`          | GET    | Detail satu siswa (aman)                                |
| `/api/students/:id`          | PUT    | Update data siswa — **deskripsi disimpan tanpa sanitasi** |
| `/api/students/:id`          | DELETE | Hapus siswa (aman)                                       |
| `/api/search?nama=...`       | GET    | Pencarian nama — **sengaja rentan SQL Injection**        |
| `/api/files?path=...`        | GET    | Memuat file foto — **sengaja rentan Path Traversal**     |

---

## 7. Celah keamanan yang disisipkan (untuk praktikum)

### a. SQL Injection — `GET /api/search`

Lokasi: `src/app/api/search/route.ts`

Query dibangun dengan string concatenation mentah:

```js
const query = `SELECT * FROM students WHERE nama_lengkap LIKE '%${nama}%'`;
```

Tidak ada prepared statement maupun validasi input. Contoh payload untuk
didemonstrasikan pada parameter `nama`:

```
' OR '1'='1
' UNION SELECT id,foto,nama_lengkap,nama_panggilan,kelas,keahlian,skill,hobi,cita_cita,deskripsi,1,1 FROM students -- -
```

**Perbaikan (untuk referensi, bukan diterapkan di lab ini):** ganti dengan
`pool.query('... WHERE nama_lengkap LIKE ?', [`%${nama}%`])`, persis pola
yang sudah dipakai di route `/api/students/:id`.

### b. Cross-Site Scripting (Stored XSS) — halaman profil siswa

Lokasi: `src/app/students/[id]/ProfileClient.tsx` (render) dan
`src/app/api/students/[id]/route.ts` (penyimpanan).

Input "Deskripsi Diri" disimpan apa adanya ke kolom `deskripsi`, lalu
dirender dengan:

```jsx
<div dangerouslySetInnerHTML={{ __html: deskripsi }} />
```

tanpa sanitasi DOM (tidak memakai DOMPurify dll). Contoh payload untuk
dicoba di form edit deskripsi:

```html
<script>alert('XSS')</script>
<img src=x onerror="alert(document.cookie)">
```

**Perbaikan (referensi):** sanitasi dengan library seperti DOMPurify
sebelum render, atau render sebagai teks biasa (`{deskripsi}`) alih-alih
`dangerouslySetInnerHTML`.

### c. Path Traversal — `GET /api/files`

Lokasi: `src/app/api/files/route.ts`

Parameter `path` digabung langsung ke direktori dasar lalu dibaca dengan
`fs.readFileSync`, tanpa memfilter `../`:

```js
const targetPath = path.join(baseDir, requestedPath);
const fileBuffer = fs.readFileSync(targetPath);
```

Contoh payload:

```
/api/files?path=../../../../etc/passwd
/api/files?path=..%2f..%2f..%2fpackage.json
```

**Perbaikan (referensi):** gunakan `path.basename()` pada input, resolve
path lalu pastikan hasilnya masih berada di dalam `baseDir` sebelum
membaca file.

---

## 8. Struktur folder

```
profil-kelas-xi-tkj-3/
├── database/
│   ├── schema.sql          # skema tabel students
│   └── seed.sql             # 32 data siswa awal
├── public/students/         # foto dummy (svg)
├── src/
│   ├── lib/db.ts            # koneksi pool MariaDB (mysql2)
│   ├── components/          # TerminalWindow, Navbar, StudentCard
│   └── app/
│       ├── page.tsx                     # Beranda
│       ├── students/page.tsx            # Daftar siswa + pencarian
│       ├── students/[id]/page.tsx       # Profil siswa
│       ├── students/[id]/ProfileClient.tsx  # form edit deskripsi (XSS)
│       └── api/
│           ├── students/route.ts        # list & create (aman)
│           ├── students/[id]/route.ts   # get/update/delete (aman)
│           ├── search/route.ts          # SQLi (sengaja rentan)
│           └── files/route.ts           # Path Traversal (sengaja rentan)
└── README.md
```
