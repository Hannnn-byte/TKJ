import type { Config } from "tailwindcss";

const config: Config = {
  content: ["./src/**/*.{js,ts,jsx,tsx,mdx}"],
  theme: {
    extend: {
      colors: {
        term: {
          bg: "#05070a",
          panel: "#0b1016",
          line: "#1c2b2e",
          green: "#39ff88",
          "green-dim": "#1f8f52",
          amber: "#ffb454",
          red: "#ff5c5c",
          cyan: "#4fd6e0",
          fg: "#c9e8d6",
          muted: "#5c7a72",
        },
      },
      fontFamily: {
        mono: [
          "JetBrains Mono",
          "Fira Code",
          "ui-monospace",
          "SFMono-Regular",
          "Menlo",
          "monospace",
        ],
      },
      boxShadow: {
        glow: "0 0 12px rgba(57,255,136,0.35)",
        "glow-amber": "0 0 12px rgba(255,180,84,0.35)",
      },
      backgroundImage: {
        scanlines:
          "repeating-linear-gradient(to bottom, rgba(57,255,136,0.035) 0px, rgba(57,255,136,0.035) 1px, transparent 1px, transparent 3px)",
        "grid-fade":
          "linear-gradient(rgba(57,255,136,0.06) 1px, transparent 1px), linear-gradient(90deg, rgba(57,255,136,0.06) 1px, transparent 1px)",
      },
      keyframes: {
        blink: { "0%,49%": { opacity: "1" }, "50%,100%": { opacity: "0" } },
        flicker: {
          "0%,100%": { opacity: "1" },
          "92%": { opacity: "1" },
          "93%": { opacity: "0.82" },
          "94%": { opacity: "1" },
        },
      },
      animation: {
        blink: "blink 1s step-end infinite",
        flicker: "flicker 6s infinite",
      },
    },
  },
  plugins: [],
};

export default config;
